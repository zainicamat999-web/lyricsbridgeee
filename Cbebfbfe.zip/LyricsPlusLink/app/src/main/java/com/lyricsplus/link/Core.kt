package com.lyricsplus.link

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

object State {
    @Volatile var running = false
    @Volatile var clients = 0
    @Volatile var title = ""
    @Volatile var artist = ""
    @Volatile var lyricStatus = "-"
    @Volatile var offset = 0.0              // detik; + = lirik lebih cepat, - = lebih lambat
    @Volatile var manualTitle: String? = null
    @Volatile var manualArtist: String? = null
    @Volatile var refetch = false
}

fun fmt(x: Double): String = String.format(Locale.US, "%.2f", x)

/** Bersihkan teks supaya aman dikirim lewat protokol lp:l / lp:t. */
fun clean(s: String): String =
    s.replace("|", "/").replace(";;", ";").replace(Regex("[\\r\\n]+"), " ").trim()

object Lrclib {
    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "LyricsPlusLink/1.0")
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    private fun q(s: String) = URLEncoder.encode(s, "UTF-8")

    fun find(title: String, artist: String, durSec: Long): List<Pair<Double, String>> {
        var synced: String? = null
        val dur = if (durSec > 0) "&duration=$durSec" else ""
        get("https://lrclib.net/api/get?track_name=${q(title)}&artist_name=${q(artist)}$dur")?.let {
            val s = JSONObject(it).optString("syncedLyrics")
            if (s.isNotBlank() && s != "null") synced = s
        }
        if (synced == null) {
            get("https://lrclib.net/api/search?q=${q("$title $artist")}")?.let {
                val arr = JSONArray(it)
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i).optString("syncedLyrics")
                    if (s.isNotBlank() && s != "null") { synced = s; break }
                }
            }
        }
        return parse(synced ?: return emptyList())
    }

    private val re = Regex("""\[(\d+):(\d+(?:\.\d+)?)]""")

    private fun parse(lrc: String): List<Pair<Double, String>> {
        val out = mutableListOf<Pair<Double, String>>()
        for (line in lrc.lines()) {
            val ms = re.findAll(line).toList()
            if (ms.isEmpty()) continue
            val text = line.substring(ms.last().range.last + 1).trim()
            for (m in ms) out += (m.groupValues[1].toInt() * 60 + m.groupValues[2].toDouble()) to text
        }
        return out.sortedBy { it.first }
    }

    /** Pecah jadi chunk "t~teks;;t~teks" (maks ±700 karakter per chunk). */
    fun chunks(lines: List<Pair<Double, String>>): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for ((t, text) in lines) {
            val p = "${fmt(t)}~${clean(text)}"
            if (sb.isNotEmpty() && sb.length + p.length + 2 > 700) { out += sb.toString(); sb.clear() }
            if (sb.isNotEmpty()) sb.append(";;")
            sb.append(p)
        }
        if (sb.isNotEmpty()) out += sb.toString()
        return out
    }
}
