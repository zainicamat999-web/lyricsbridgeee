package com.lyricsplus.link

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var sw: Switch
    private val h = Handler(Looper.getMainLooper())
    private var syncing = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(0xFFB9B4CC.toInt())
        textSize = 13f
        setPadding(0, dp(16), 0, dp(4))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "LyricsPlus Link"; textSize = 24f; setTextColor(0xFFFFFFFF.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Spotify / YouTube Music → Minecraft"; setTextColor(0xFFB9B4CC.toInt())
        })

        sw = Switch(this).apply {
            text = "Hidupkan layanan"; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, dp(16), 0, dp(8))
            setOnCheckedChangeListener { _, on ->
                if (syncing) return@setOnCheckedChangeListener
                val i = Intent(this@MainActivity, LinkService::class.java)
                if (on) ContextCompat.startForegroundService(this@MainActivity, i) else stopService(i)
            }
        }
        root.addView(sw)

        root.addView(btn("Izin notifikasi (akses media)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(btn("Salin /connect") {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("connect", "/connect 127.0.0.1:8974"))
            Toast.makeText(this, "Disalin. Tempel di chat Minecraft.", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Lepas batas baterai") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        status = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); setPadding(0, dp(16), 0, 0) }
        root.addView(label("STATUS")); root.addView(status)

        root.addView(label("SINKRON LIRIK"))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun w(t: String, d: Double?) = btn(t) { State.offset = if (d == null) 0.0 else State.offset + d }
            .also { row.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        w("Lambat −0.5", -0.5); w("Reset", null); w("Cepat +0.5", 0.5)
        root.addView(row)

        root.addView(label("CARI LIRIK MANUAL"))
        val et = EditText(this).apply { hint = "Judul"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF888888.toInt()) }
        val ea = EditText(this).apply { hint = "Artis"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF888888.toInt()) }
        root.addView(et); root.addView(ea)
        root.addView(btn("Cari lirik") {
            State.manualTitle = et.text.toString(); State.manualArtist = ea.text.toString(); State.refetch = true
        })

        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF14121C.toInt()); addView(root) })
        poll()
    }

    private fun poll() {
        val acc = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        syncing = true; sw.isChecked = State.running; syncing = false
        status.text = buildString {
            append("Akses notifikasi: ").append(if (acc) "✔ aktif" else "✘ belum (tekan Izin notifikasi)").append('\n')
            append("Layanan: ").append(if (State.running) "✔ jalan (127.0.0.1:8974)" else "✘ mati").append('\n')
            append("Minecraft: ").append(if (State.clients > 0) "✔ terhubung" else "belum, ketik /connect 127.0.0.1:8974").append('\n')
            append("Lagu: ").append(if (State.title.isBlank()) "(belum ada lagu)" else "${State.artist} - ${State.title}").append('\n')
            append("Lirik: ").append(State.lyricStatus).append('\n')
            append("Geser: ").append(String.format("%+.1f detik", State.offset))
        }
        h.postDelayed({ poll() }, 500)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
