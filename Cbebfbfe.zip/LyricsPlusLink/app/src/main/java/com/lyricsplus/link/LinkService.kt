package com.lyricsplus.link

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Dibutuhkan supaya app boleh membaca sesi media (izin akses notifikasi). */
class MediaListener : NotificationListenerService()

class LinkService : Service() {
    private val port = 8974
    private var server: WebSocketServer? = null
    private var exec: ScheduledExecutorService? = null

    private var curKey = ""
    private var baseId = "-"
    private var rev = 0
    private var lastClients = 0
    private var tick = 0
    @Volatile private var fetching = false
    @Volatile private var dirty = false
    @Volatile private var chunks: List<String> = emptyList()
    @Volatile private var gen = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (State.running) return START_STICKY
        startFg()
        startServer()
        exec = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleWithFixedDelay({ try { loop() } catch (_: Throwable) {} }, 0, 1, TimeUnit.SECONDS)
        }
        State.running = true
        return START_STICKY
    }

    override fun onDestroy() {
        exec?.shutdownNow()
        try { server?.stop(0) } catch (_: Exception) {}
        State.running = false
        State.clients = 0
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("link", "LyricsPlus Link", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "link")
            .setContentTitle("LyricsPlus Link aktif")
            .setContentText("Server 127.0.0.1:$port")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun startServer() {
        server = object : WebSocketServer(InetSocketAddress("127.0.0.1", port)) {
            override fun onOpen(c: WebSocket, h: ClientHandshake) {}
            override fun onClose(c: WebSocket, code: Int, reason: String, remote: Boolean) {}
            override fun onMessage(c: WebSocket, m: String) {}
            override fun onError(c: WebSocket?, e: Exception) {}
            override fun onStart() {}
        }.also { it.isReuseAddr = true; it.start() }
    }

    private fun cmd(line: String): String = JSONObject().apply {
        put("header", JSONObject()
            .put("version", 1)
            .put("requestId", UUID.randomUUID().toString())
            .put("messagePurpose", "commandRequest")
            .put("messageType", "commandRequest"))
        put("body", JSONObject()
            .put("origin", JSONObject().put("type", "player"))
            .put("commandLine", line)
            .put("version", 1))
    }.toString()

    private fun send(line: String) { try { server?.broadcast(cmd(line)) } catch (_: Exception) {} }

    private fun pick(): MediaController? {
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = try {
            msm.getActiveSessions(ComponentName(this, MediaListener::class.java))
        } catch (e: SecurityException) {
            State.lyricStatus = "Izin akses notifikasi belum aktif"
            return null
        }
        return list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
    }

    private fun fetch(title: String, artist: String, durSec: Long) {
        val g = ++gen
        fetching = true
        State.lyricStatus = "Mencari lirik..."
        thread {
            val lines = try { Lrclib.find(title, artist, durSec) } catch (_: Exception) { emptyList() }
            if (g != gen) return@thread
            chunks = Lrclib.chunks(lines)
            State.lyricStatus = if (lines.isEmpty()) "Lirik tidak ditemukan" else "${lines.size} baris"
            dirty = true
            fetching = false
        }
    }

    private fun loop() {
        val srv = server ?: return
        val n = srv.connections.size
        State.clients = n
        val justConnected = n > lastClients
        lastClients = n

        val ctrl = pick()
        val md = ctrl?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        if (ctrl == null || title.isBlank()) {
            State.title = ""; State.artist = ""
            if (n > 0) send("scriptevent lp:t -|0|0|0|0|-|-")
            return
        }
        State.title = title; State.artist = artist

        val st = ctrl.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        val posMs = when {
            st == null -> 0L
            playing -> st.position + ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            else -> st.position
        }
        val durMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        val key = "$title\u0000$artist"
        if (key != curKey) {
            curKey = key
            baseId = Integer.toHexString(key.hashCode())
            rev = 0
            State.manualTitle = null; State.manualArtist = null
            chunks = emptyList()
            fetch(title, artist, durMs / 1000)
        } else if (State.refetch) {
            State.refetch = false
            rev++
            chunks = emptyList()
            fetch(State.manualTitle?.ifBlank { null } ?: title, State.manualArtist?.ifBlank { null } ?: artist, durMs / 1000)
        }

        if (n > 0) {
            val id = if (rev == 0) baseId else "$baseId.$rev"
            val cs = chunks
            if (!fetching) {
                if (cs.isNotEmpty() && (justConnected || dirty || tick % 10 == 0)) {
                    cs.forEachIndexed { k, c -> send("scriptevent lp:l $id|$k|${cs.size}|$c") }
                }
                dirty = false
            }
            val pos = (posMs / 1000.0 + State.offset).coerceAtLeast(0.0)
            // Selama lirik masih dicari kirim id "-" supaya add-on tidak terlanjur menganggap "tanpa lirik".
            val sendId = if (fetching) "-" else id
            send("scriptevent lp:t $sendId|${if (playing) 1 else 0}|${fmt(pos)}|${fmt(durMs / 1000.0)}|${cs.size}|${clean(title)}|${clean(artist)}")
        }
        tick++
    }
}
