plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.lyricsplus.link"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.lyricsplus.link"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.java-websocket:Java-WebSocket:1.5.7")
    implementation("androidx.core:core-ktx:1.13.1")
}
