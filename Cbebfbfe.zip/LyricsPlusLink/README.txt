LyricsPlus Link - cara build
1. Buka folder ini di Android Studio (File > Open), tunggu Gradle sync selesai.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk
3. Install di HP, buka app, Izin notifikasi > aktifkan LyricsPlus Link, nyalakan layanan.
4. Di Minecraft (matikan WebSocket terenkripsi, dunia aktif cheat): /connect 127.0.0.1:8974
Android 13+: jika izin notifikasi abu-abu, buka Info aplikasi > titik tiga > "Izinkan setelan terbatas".
